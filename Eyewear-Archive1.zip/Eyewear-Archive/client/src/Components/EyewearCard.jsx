import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";

const EyewearCard = ({ eyewear }) => {
  return (
    <Card
      sx={{
        width: "30vw",
        marginLeft: "5vw",
        backgroundColor: "rgba(255, 0, 0, 0.2)",
        color: "white",
      }}>
      <CardMedia
        component="img"
        height="200"
        image={eyewear.image}
        alt={eyewear.name}
      />
      <CardContent>
        <Typography variant="h5" component="h2">
          {eyewear.name} ( {eyewear.price} )
        </Typography>
        <Typography variant="body2" component="p" sx={{ paddingTop: "2rem" }}>
          {eyewear.description}
        </Typography>
        <Typography>
          <h2>Era: </h2>
          {eyewear.eraNames.join(", ")}
        </Typography>
        <Typography>
          <h2>Type: </h2>
          {eyewear.typeNames.join(", ")}
        </Typography>
        <Typography>
          <h2>Material: </h2>
          {eyewear.materialNames.join(", ")}
        </Typography>
        <Typography>
          <h2>Maker: </h2>
          {eyewear.makerNames.join(", ")}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default EyewearCard;
