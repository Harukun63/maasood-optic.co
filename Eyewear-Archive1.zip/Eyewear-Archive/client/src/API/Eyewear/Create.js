import axios from "axios";

const createEyewear = async (eyewear, token) => {
  try {
    const url = process.env.REACT_APP_API_URL;

    const response = await axios.post(`${url}/eyewear/create`, eyewear, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    return error.response.data;
  }
};

export default createEyewear;
