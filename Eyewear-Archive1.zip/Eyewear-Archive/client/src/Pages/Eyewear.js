import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import CreateEyewear from "../API/Eyewear/Create";
import ViewAllEyewear from "../API/Eyewear/ViewAll";
import ViewAllMaterials from "../API/Material/ViewAll";
import ViewAllTypes from "../API/Type/ViewAll";
import Pagination from "@mui/material/Pagination";
import NavBar from "../Components/NavBar";
import EyewearCard from "../Components/EyewearCard";

const Eyewear = () => {
  const userEmail = useSelector((state) => state.user.email);
  const userToken = useSelector((state) => state.user.token);

  const adminEmail = process.env.REACT_APP_ADMIN_EMAIL;

  const [eyewear, setEyewear] = useState([]);
  const [newEyewear, setNewEyewear] = useState({
    name: "",
    description: "",
    price: "",
    image: "",
    typeIDs: [],
    materialIDs: [],
  });
  const [materials, setMaterials] = useState([]);
  const [types, setTypes] = useState([]);
  const [page, setPage] = useState(1);
  const [perPage] = useState(3); // Set number of eyewear per page

  useEffect(() => {
    const fetchNamesFromIDs = async (Model, ids) => {
      try {
        // Filter out undefined values
        const names = (
          await Promise.all(
            Model.map(async (mod) => {
              if (ids.includes(mod._id)) {
                return mod.name;
              }
            })
          )
        ).filter((name) => name !== undefined);
        return names;
      } catch (error) {
        console.error("Error fetching names:", error);
        throw error;
      }
    };

    const fetchData = async () => {
      try {
        const eyewearAPI = await ViewAllEyewear(userToken);
        const materialsAPI = await ViewAllMaterials(userToken);
        const typesAPI = await ViewAllTypes(userToken);

        const eyewearNamed = await Promise.all(
          eyewearAPI.map(async (eyewear) => {
            const typeNames = await fetchNamesFromIDs(
              typesAPI,
              eyewear.typeIDs
            );
            const materialNames = await fetchNamesFromIDs(
              materialsAPI,
              eyewear.materialIDs
            );
            return {
              ...eyewear,
              typeNames: typeNames,
              materialNames: materialNames,
            };
          })
        );

        // Set eyewear with eyewearNamed instead of eyewearAPI
        setEyewear(Array.isArray(eyewearNamed) ? eyewearNamed : []);
        setMaterials(materialsAPI);
        setTypes(typesAPI);

        console.log("Data fetched");
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [userToken]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const startIndex = (page - 1) * perPage;
  const endIndex = Math.min(startIndex + perPage, eyewear.length);
  const paginatedEyewear = eyewear.slice(startIndex, endIndex);

  const handleAddEyewear = (e) => {
    e.preventDefault();
    CreateEyewear(newEyewear, userToken);
    console.log("Eyewear added");
    setNewEyewear({
      name: "",
      description: "",
      price: "",
      image: "",
      eraIDs: [],
      typeIDs: [],
      materialIDs: [],
      makerIDs: [],
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewEyewear((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  return (
    <div>
      {userEmail === "" && userToken === "" ? (
        <>
          <iframe
            src="https://lottie.host/embed/1735cc84-8331-411b-9839-ec699469defc/EYzL2DAfWT.json"
            height="500vh"
            width="100%"
            frameBorder="none"
            title="Login First"></iframe>

          <Button
            href="/"
            variant="contained"
            color="primary"
            sx={{ width: "20vw", marginLeft: "40vw" }}>
            Login To View
          </Button>
        </>
      ) : (
        <>
          <NavBar />

          <div>
            <Typography variant="h4" style={{ marginBottom: "1rem" }}>
              Eyewear
            </Typography>
            <div className="eyewear-container">
              {paginatedEyewear.map((eyewear) => (
                <EyewearCard key={eyewear._id} eyewear={eyewear} />
              ))}
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "20px",
                backgroundColor: "red",
                width: "50vw",
                marginLeft: "25vw",
              }}>
              <Pagination
                count={Math.ceil(eyewear.length / perPage)}
                page={page}
                onChange={handleChangePage}
              />
            </div>
          </div>

          {userEmail === adminEmail && (
            <div
              style={{
                backgroundColor: "#ffffff",
                width: "70%",
                marginLeft: "14%",
                marginBottom: "2rem",
                marginTop: "2rem",
                padding: "1rem",
                borderRadius: "8px",
              }}>
              <Typography
                variant="h4"
                style={{
                  color: "red",
                  fontWeight: "900",
                  marginBottom: "1rem",
                  paddingLeft: "42%",
                }}>
                Add Eyewear
              </Typography>

              <form onSubmit={handleAddEyewear}>
                <TextField
                  label="Name"
                  variant="outlined"
                  fullWidth
                  name="name"
                  value={newEyewear.name}
                  onChange={handleInputChange}
                  style={{ marginBottom: "1rem" }}
                />
                <TextField
                  label="Description"
                  variant="outlined"
                  fullWidth
                  name="description"
                  value={newEyewear.description}
                  onChange={handleInputChange}
                  style={{ marginBottom: "1rem" }}
                />
                <TextField
                  label="Manufactured Year"
                  variant="outlined"
                  fullWidth
                  name="price"
                  value={newEyewear.price}
                  onChange={handleInputChange}
                  style={{ marginBottom: "1rem" }}
                />
                <TextField
                  label="Image URL"
                  variant="outlined"
                  fullWidth
                  name="image"
                  value={newEyewear.image}
                  onChange={handleInputChange}
                  style={{ marginBottom: "1rem" }}
                />

                <TextField
                  select
                  label="Type Name"
                  variant="outlined"
                  fullWidth
                  name="typeIDs"
                  value={newEyewear.typeIDs}
                  onChange={handleInputChange}
                  SelectProps={{ multiple: true }}
                  style={{ marginBottom: "1rem" }}>
                  {types.map((type) => (
                    <MenuItem key={type.id} value={type._id}>
                      {type.name}
                    </MenuItem>
                  ))}
                </TextField>

                <TextField
                  select
                  label="Material Name"
                  variant="outlined"
                  fullWidth
                  name="materialIDs"
                  value={newEyewear.materialIDs}
                  onChange={handleInputChange}
                  SelectProps={{ multiple: true }}
                  style={{ marginBottom: "1rem" }}>
                  {materials.map((material) => (
                    <MenuItem key={material.id} value={material._id}>
                      {material.name}
                    </MenuItem>
                  ))}
                </TextField>

                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  style={{ display: "block", margin: "0 auto" }}>
                  Add Eyewear
                </Button>
              </form>
            </div>
          )}

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "20px",
            }}>
            <Pagination
              count={Math.ceil(eyewear.length / perPage)}
              page={page}
              onChange={handleChangePage}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default Eyewear;
