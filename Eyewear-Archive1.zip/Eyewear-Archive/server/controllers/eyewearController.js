const eyewearModel = require("../models/eyewearModel");
const typeModel = require("../models/typeModel");

const eyewearController = {
  // Create a new eyewear
  async create(req, res) {
    try {
      // Extracting data from request body
      const {
        name,
        description,
        image,
        price,
        eraIDs,
        typeIDs,
        materialIDs,
        makerIDs,
      } = req.body;

      // Convert string price to number
      setPrice = parseFloat(price);

      // Creating a new eyewear instance
      const new_eyewear = new eyewearModel({
        name,
        description,
        image,
        setPrice,
        eraIDs,
        typeIDs,
        materialIDs,
        makerIDs,
      });

      // Saving the new eyewear to the database
      const saved_eyewear = await new_eyewear.save();

      res.status(201).json(saved_eyewear); // Respond with the created eyewear
    } catch (error) {
      res.status(400).json({ message: error.message }); // Respond with any error that occurred
    }
  },

  // Get all eyewears
  async getAll(req, res) {
    try {
      const eyewears = await eyewearModel.find();
      res.send(eyewears);
    } catch (err) {
      res.status(400).send(err.message);
    }
  },

  // Filter eyewears by type name in parameters
  async getByType(req, res) {
    try {
      const type = await typeModel.findOne({ name: req.params.name });
      const eyewears = await eyewearModel.find({ typeIDs: type._id });
      res.send(eyewears);
    } catch (err) {
      res.status(400).send(err.message);
    }
  },

  // Remove eyewear by name
  async remove(req, res) {
    try {
      const removedeyewear = await eyewearModel.findOneAndDelete({
        _id: req.params.id,
      });
      res.send(removedeyewear);
    } catch (err) {
      res.status(400).send(err.message);
    }
  },
};

module.exports = eyewearController;
