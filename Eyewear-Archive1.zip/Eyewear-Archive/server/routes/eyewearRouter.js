const express = require('express');
const router = express.Router();

const eyewearController = require('../controllers/eyewearController');
const authAdmin = require('../middleware/authAdmin');
const auth = require('../middleware/auth');

router.post('/create', auth, authAdmin, eyewearController.create);
router.get('/all', auth, eyewearController.getAll);
router.delete('/remove/:name', auth, authAdmin, eyewearController.remove);

router.get('/filter/:name', auth, eyewearController.getByType);

module.exports = router;